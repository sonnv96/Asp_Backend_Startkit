﻿using System;
using AutoMapper;
using Nois.WebApi.Framework;
using System.Collections.Generic;
$if$ ($targetframeworkversion$ >= 3.5)using System.Linq;
$endif$using System.Text;
using Swashbuckle.Swagger.Annotations;
using System.Web.Http;
using System.Net;

namespace $rootnamespace$
{
    /// <summary>
    /// $fileinputname$ Api
    /// </summary>
    [RoutePrefix("$lowercasetypename$s")]
    public class $fileinputname$Controller : BaseApiController
	{
        /// <summary>
        /// Get list $fileinputname$
        /// </summary>
        /// <remarks>
        /// When user want to get list $fileinputname$, use this API for getting
        /// </remarks>
        /// <returns></returns>
        [Route("")]
        [SwaggerResponse(200, "Returns the result of get list $fileinputname$", typeof($fileinputname$ListModel))]
        [SwaggerResponse(500, "Internal Server Error")]
        [SwaggerResponse(400, "Bad Request")]
        [SwaggerResponse(401, "Not Authorizated")]
        [HttpGet]
        public IHttpActionResult List()
        {
            var model = new $fileinputname$ListModel();

            try
            {
                //Get list $fileinputname$
                var $vartypename$s = _$vartypename$Service.GetAll();
                if ($vartypename$s == null)
                {
                    //not create before
                    model.ErrorMessages.Add("$fileinputname$.NotFound");
                    return new HttpApiActionResult(HttpStatusCode.BadRequest, model);
                }

                Mapper.Map($vartypename$s, model.$fileinputname$List);


                return new HttpApiActionResult(HttpStatusCode.OK, model);
            }
            catch (Exception ex)
            {
                model.ErrorMessages.Add(ex.Message);
                return new HttpApiActionResult(HttpStatusCode.BadRequest, model);
            }
        }

        /// <summary>
        /// Get a $fileinputname$ detail 
        /// </summary>
        /// <remarks>
        /// When user want to get a $fileinputname$ detail, use this API for getting
        /// </remarks>
        /// <param name="id">$fileinputname$ identity</param>
        /// <returns></returns>
        [Route("{id}")]
        [SwaggerResponse(200, "Returns the result of get a $fileinputname$ detail", typeof($fileinputname$DetailModel))]
        [SwaggerResponse(500, "Internal Server Error")]
        [SwaggerResponse(400, "Bad Request")]
        [SwaggerResponse(401, "Not Authorizated")]
        [HttpGet]
        public IHttpActionResult Detail(int id)
        {
            var $vartypename$ = _$vartypename$Service.GetById(id);

            var model = new $fileinputname$DetailModel();
            if ($vartypename$ == null)
            {
                model.ErrorMessages.Add("$fileinputname$.NotFound");
                return new HttpApiActionResult(HttpStatusCode.BadRequest, model);
            }

            Mapper.Map($vartypename$, model);

            model.Messages = new List<string> { "Successful!" };

            return new HttpApiActionResult(HttpStatusCode.OK, model);
        }

        /// <summary>
        /// Add a $fileinputname$
        /// </summary>
        /// <remarks>
        /// When user want to add a $fileinputname$, use this API for getting
        /// </remarks>
        /// <returns></returns>
        [Route("")]
        [SwaggerResponse(200, "Returns the result of add a $fileinputname$", typeof(ApiJsonResult))]
        [SwaggerResponse(500, "Internal Server Error")]
        [SwaggerResponse(400, "Bad Request")]
        [SwaggerResponse(401, "Not Authorizated")]
        [HttpPost]
        public IHttpActionResult Add($fileinputname$EditModel model)
        {
            var res = new ApiJsonResult();

            try
            {
                //Check is valid
                if (!ModelState.IsValid)
                {
                    res.ErrorMessages.AddRange(ModelState.ToListErrorMessage());
                    return new HttpApiActionResult(HttpStatusCode.BadRequest, res);
                }

                //Create $fileinputname$
                var $vartypename$ = Mapper.Map<$fileinputname$EditModel, $fileinputname$ > (model);

                //Save to database
                _$vartypename$Service.Insert($vartypename$);

                return new HttpApiActionResult(HttpStatusCode.OK, res);
            }
            catch (Exception ex)
            {
                res.ErrorMessages.Add(ex.Message);
                return new HttpApiActionResult(HttpStatusCode.BadRequest, res);
            }
        }

        /// <summary>
        /// Update a $fileinputname$
        /// </summary>
        /// <remarks>
        /// When user want to update a $fileinputname$, use this API for getting
        /// </remarks>
        /// <returns></returns>
        [Route("")]
        [SwaggerResponse(200, "Returns the result of update a $fileinputname$", typeof(ApiJsonResult))]
        [SwaggerResponse(500, "Internal Server Error")]
        [SwaggerResponse(400, "Bad Request")]
        [SwaggerResponse(401, "Not Authorizated")]
        [HttpPut]
        public IHttpActionResult Update($fileinputname$EditModel model)
        {
            var res = new ApiJsonResult();

            try
            {
                //Check data is valid
                if (!ModelState.IsValid)
                {
                    res.ErrorMessages.AddRange(ModelState.ToListErrorMessage());
                    return new HttpApiActionResult(HttpStatusCode.BadRequest, res);
                }
                //Get $fileinputname$ by identity
                var $vartypename$ = _$vartypename$Service.GetById(model.Id);
                if ($vartypename$ == null)
                {
                    res.ErrorMessages.Add("$fileinputname$.NotFound.");
                    return Json(res);
                }

                //Update $fileinputname$
                Mapper.Map(model, $vartypename$);

                //update
                _$vartypename$Service.Update($vartypename$);

                return new HttpApiActionResult(HttpStatusCode.OK, res);
            }
            catch (Exception ex)
            {
                res.ErrorMessages.Add(ex.Message);
                return new HttpApiActionResult(HttpStatusCode.BadRequest, res);
            }
        }

        /// <summary>
        /// Delete a $fileinputname$
        /// </summary>
        /// <remarks>
        /// When user want to delete a $fileinputname$, use this API for getting<br/>
        /// </remarks>
        /// <param name="id">$fileinputname$ identity</param>
        /// <returns></returns>
        [Route("{id}")]
        [SwaggerResponse(200, "Returns the result of delete a $fileinputname$", typeof(ApiJsonResult))]
        [SwaggerResponse(500, "Internal Server Error")]
        [SwaggerResponse(400, "Bad Request")]
        [SwaggerResponse(401, "Not Authorizated")]
        [HttpDelete]
        public IHttpActionResult Delete(int id)
        {
            var res = new ApiJsonResult();

            try
            {
                //Get $fileinputname$ by identity
                var $vartypename$ = _$vartypename$Service.GetById(id);
                if ($vartypename$ == null)
                {
                    res.ErrorMessages.Add("$fileinputname$.NotFound.");
                    return new HttpApiActionResult(HttpStatusCode.BadRequest, res);
                }

                _$vartypename$Service.Delete($vartypename$);

                return new HttpApiActionResult(HttpStatusCode.OK, res);
            }
            catch (Exception ex)
            {
                res.ErrorMessages.Add("$fileinputname$.CannotDelete");
                return new HttpApiActionResult(HttpStatusCode.BadRequest, res);
            }
        }
    }
}
