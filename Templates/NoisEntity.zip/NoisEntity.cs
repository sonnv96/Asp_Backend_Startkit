﻿using Nois.Framework.Data;
using System.Data.Entity.ModelConfiguration;

namespace $rootnamespace$
{
    /// <summary>
    /// $safeitemname$ entity
    /// </summary>
    public class $safeitemname$ : BaseEntity
    {
    }

    /// <summary>
    /// $safeitemname$ mapping
    /// </summary>
    public class $safeitemname$Map : EntityTypeConfiguration<$safeitemname$>
    {
        public $safeitemname$Map()
        {
            this.ToTable("$safeitemname$");
            this.HasKey(c => c.Id);
        }
    }
}
