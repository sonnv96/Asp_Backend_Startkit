﻿using System;
using System.Web;
using System.Linq;
using AutoMapper;
using FluentValidation;
using FluentValidation.Attributes;
using System.Collections.Generic;
using Nois.WebApi.Framework;

namespace $rootnamespace$
{

    #region Models

    /// <summary>
    /// $fileinputname$ item model
    /// </summary>
    public class $fileinputname$Model
    {
        /// <summary>
        /// $fileinputname$ identity
        /// </summary>
        public int Id { get; set; }
    }

    /// <summary>
    /// $fileinputname$ list model
    /// </summary>
    public class $fileinputname$ListModel : ApiJsonResult
    {
        /// <summary>
        /// Default contructor
        /// </summary>
        public $fileinputname$ListModel()
{
            $fileinputname$List = new List<$fileinputname$Model>();
        }
        /// <summary>
        /// List of user roles
        /// </summary>
        public List<$fileinputname$Model> $fileinputname$List { get; set; }
    }

    /// <summary>
    /// $fileinputname$ detail model
    /// </summary>
    public class $fileinputname$DetailModel : ApiJsonResult
    {
        /// <summary>
        /// $fileinputname$ identity
        /// </summary>
        public int Id { get; set; }
    }

    /// <summary>
    /// $fileinputname$ edit model
    /// </summary>
    [Validator(typeof($fileinputname$EditValidator))]
    public class $fileinputname$EditModel
    {
        /// <summary>
        /// $fileinputname$ identity
        /// </summary>
        public int Id { get; set; }
    }

    #endregion

    #region Mappings

    /// <summary>
    /// Implement $fileinputname$ Map
    /// </summary>
    public class MapperRegistrar : IMapperRegistrar
    {
        public int Order
        {
            get
            {
                return 1;
            }
        }

        public void Register(IMapperConfigurationExpression config)
        {
            config.CreateMap<$fileinputname$, $fileinputname$Model > ();
            config.CreateMap <$fileinputname$, $fileinputname$DetailModel > ();
            config.CreateMap<$fileinputname$, $fileinputname$EditModel > ();
            config.CreateMap<$fileinputname$EditModel, $fileinputname$ > ();
        }
    }

    #endregion

    #region Validators

    /// <summary>
    /// Validate for $fileinputname$EditModel
    /// </summary>
    public class $fileinputname$EditValidator : AbstractValidator<$fileinputname$EditModel>
    {
        /// <summary>
        /// Define validators here
        /// </summary>
        public $fileinputname$EditValidator()
        {

        }
    }

    #endregion
}