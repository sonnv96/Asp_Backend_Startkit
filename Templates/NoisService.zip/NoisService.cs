﻿using System.Linq;
using System.Threading.Tasks;
using Nois.Framework.Services;
using Nois.Framework.Data;
using Nois.Framework.Caching;

namespace $rootnamespace$
{
    /// <summary>
    /// $fileinputname$ service
    /// </summary>
    public class $safeitemname$ : BaseService<$fileinputname$>, I$safeitemname$
    {
        public $safeitemname$(IRepository<$fileinputname$> tRepository,
            ICacheManager cacheManager) : base(tRepository, cacheManager)
        {
        }

        protected override string PatternKey
        {
            get
            {
                return "Nois.$fileinputname$.";
            }
        }
    }
}
