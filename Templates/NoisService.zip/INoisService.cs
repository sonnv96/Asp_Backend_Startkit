﻿using System.Linq;
using System.Threading.Tasks;
using Nois.Framework.Services;

namespace $rootnamespace$
{
    /// <summary>
    /// $fileinputname$ service interface
    /// </summary>
    public interface $safeitemname$ : IBaseService<$fileinputname$>
    {
    }
}
